/*
 * Copyright 2002 Lite Speed Technologies Inc, All Rights Reserved.
 * LITE SPEED PROPRIETARY/CONFIDENTIAL.
 */


#ifndef MY_SLEEP_H_
#define MY_SLEEP_H_

#ifdef __cplusplus
extern "C"
{
#endif

extern void my_sleep(int millisec);

#ifdef __cplusplus
}
#endif

#endif
