
#include <lsmcd.h>

int main(int argc, char **argv) 
{
    return Lsmcd::getInstance().Main( argc, argv );
}
