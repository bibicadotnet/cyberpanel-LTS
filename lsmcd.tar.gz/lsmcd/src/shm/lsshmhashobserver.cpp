/*
 * 
 */

#include "lsshmhashobserver.h"

LsShmHashObserver::LsShmHashObserver(LsShmHash *pHash)
    : m_pHash(pHash)
{}

LsShmHashObserver::~LsShmHashObserver()
{}
