
#include <replserver.h>

int main(int argc, char **argv) 
{
 
    return ReplServer::getInstance().Main( argc, argv );
}
